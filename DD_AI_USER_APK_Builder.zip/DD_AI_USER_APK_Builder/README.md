# DD AI USER APK Builder

This Android WebView wrapper opens the DD AI USER Node.js app at `http://127.0.0.1:3000`.
It is designed to run alongside the existing Termux server; Termux must remain running while using the APK.

## Build the APK using GitHub Actions (phone-friendly)
1. Create a new GitHub repository, for example `dd-ai-user-apk`.
2. Extract this ZIP and upload **the contents** of this folder to the repository root (not the outer folder itself).
3. Open the repository's **Actions** tab. If prompted, enable workflows.
4. Select **Build DD AI USER APK** and tap **Run workflow**. A push to `main`/`master` also triggers a build.
5. Wait for the run to finish successfully. Open the run, scroll to **Artifacts**, and download `DD-AI-USER-APK`.
6. Extract the downloaded artifact ZIP and install `app-debug.apk`. Allow Android to install apps from that source if prompted.

## Run on your phone
1. Start the existing Node server in Termux as usual:
   `cd ~/storage/downloads/DD_Maths_Help_AI && bash start.sh`
2. Keep Termux and the server process running.
3. Open the DD AI USER APK. It connects to `http://127.0.0.1:3000` on the same phone.

## Notes
- This is a local WebView wrapper, not a standalone server. It will not work if the Termux server is stopped.
- The APK requests Internet access and supports file selection for image/document uploads.
- Debug APK is unsigned for Play Store distribution; it can be installed manually on your own Android device.
